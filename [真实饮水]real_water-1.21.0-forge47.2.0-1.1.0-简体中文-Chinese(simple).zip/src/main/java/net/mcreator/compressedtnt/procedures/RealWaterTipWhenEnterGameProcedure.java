package net.mcreator.compressedtnt.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.player.PlayerEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

import net.mcreator.compressedtnt.RealWaterMod;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class RealWaterTipWhenEnterGameProcedure {
	@SubscribeEvent
	public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
		execute(event, event.getEntity().level(), event.getEntity());
	}

	public static void execute(LevelAccessor world, Entity entity) {
		execute(null, world, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		RealWaterMod.queueServerWork(60, () -> {
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u8FD9\u4E2A\u4E16\u754C\u52A0\u8F7D\u4E86\u771F\u5B9E\u996E\u6C34\u6A21\u7EC4\uFF0C\u8F93\u5165/realwaterhelp\u83B7\u53D6\u6B64\u6A21\u7EC4\u7684\u5E2E\u52A9"), false);
		});
	}
}
