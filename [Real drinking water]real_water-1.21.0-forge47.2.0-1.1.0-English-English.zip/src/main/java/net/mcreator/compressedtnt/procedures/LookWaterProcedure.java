package net.mcreator.compressedtnt.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

import net.mcreator.compressedtnt.network.RealWaterModVariables;

public class LookWaterProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal(("You now have" + (entity.getCapability(RealWaterModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new RealWaterModVariables.PlayerVariables())).water + "water (up to 20)")), false);
	}
}
