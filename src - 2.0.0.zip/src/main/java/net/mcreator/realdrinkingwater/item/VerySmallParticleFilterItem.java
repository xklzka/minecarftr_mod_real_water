
package net.mcreator.realdrinkingwater.item;

public class VerySmallParticleFilterItem extends Item {
	public VerySmallParticleFilterItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
