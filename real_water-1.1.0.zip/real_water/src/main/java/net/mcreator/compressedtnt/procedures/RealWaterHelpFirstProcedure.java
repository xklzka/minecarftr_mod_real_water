package net.mcreator.compressedtnt.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

public class RealWaterHelpFirstProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("\u8F93\u5165\u2018/reahwaterhelp \u9875\u7801\u2019\u4EE5\u83B7\u53D6\u5E2E\u52A9 "), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("\u7B2C1\u9875:\u57FA\u672C\u7269\u54C1\u4E0E\u5408\u6210\u3002"), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("\u7B2C2\u9875:\u51C0\u6C34\u5668\u4E0E\u7EAF\u51C0\u6C34\u4E0E\u5176\u5408\u6210(1)\u3002"), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("\u7B2C3\u9875:\u51C0\u6C34\u5668\u4E0E\u7EAF\u51C0\u6C34\u4E0E\u5176\u5408\u6210(2)\u3002"), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("\u7B2C4\u9875:\u996E\u6C34\u673A\u5236\u3002"), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("\u7B2C5\u9875:\u6307\u4EE4\u53CA\u5176\u4ED6\u3002"), false);
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal("\u6CE8\u610F:\u82E5\u672A\u73A9\u8FC7\u6B64\u6A21\u7EC4\uFF0C\u8BF7\u89C2\u770B1-5\u9762\u7684\u00A74\u5168\u90E8\u5185\u5BB9\u00A7r!!!"), false);
	}
}
