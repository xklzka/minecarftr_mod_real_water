
package net.mcreator.realdrinkingwater.item;

public class LittleStoneItem extends Item {
	public LittleStoneItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
