
package net.mcreator.compressedtnt.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class LittleBulkyCottonItem extends Item {
	public LittleBulkyCottonItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
