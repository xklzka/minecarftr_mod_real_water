
package net.mcreator.realdrinkingwater.item;

public class ActivatedCarbonParticleFilterItem extends Item {
	public ActivatedCarbonParticleFilterItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
