
package net.mcreator.realdrinkingwater.item;

public class SmallParticleFilterItem extends Item {
	public SmallParticleFilterItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
