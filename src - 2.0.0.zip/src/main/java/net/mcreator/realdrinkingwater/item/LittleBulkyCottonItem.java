
package net.mcreator.realdrinkingwater.item;

public class LittleBulkyCottonItem extends Item {
	public LittleBulkyCottonItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
