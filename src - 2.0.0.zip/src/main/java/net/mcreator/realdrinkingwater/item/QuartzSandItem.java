
package net.mcreator.realdrinkingwater.item;

public class QuartzSandItem extends Item {
	public QuartzSandItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
