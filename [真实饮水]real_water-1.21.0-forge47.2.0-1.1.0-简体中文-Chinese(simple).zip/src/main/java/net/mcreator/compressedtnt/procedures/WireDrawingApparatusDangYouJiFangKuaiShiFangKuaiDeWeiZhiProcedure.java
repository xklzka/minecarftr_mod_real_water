package net.mcreator.compressedtnt.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.core.BlockPos;

import net.mcreator.compressedtnt.init.RealWaterModBlocks;

public class WireDrawingApparatusDangYouJiFangKuaiShiFangKuaiDeWeiZhiProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.WHITE_WOOL) {
			{
				ItemStack _ist = (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY);
				if (_ist.hurt(1, RandomSource.create(), null)) {
					_ist.shrink(1);
					_ist.setDamageValue(0);
				}
			}
			if (Mth.nextInt(RandomSource.create(), 1, 3) == 1) {
				world.setBlock(BlockPos.containing(x, y, z), RealWaterModBlocks.BULKY_COTTON_3.get().defaultBlockState(), 3);
			}
		} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == RealWaterModBlocks.BULKY_COTTON_3.get()) {
			{
				ItemStack _ist = (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY);
				if (_ist.hurt(1, RandomSource.create(), null)) {
					_ist.shrink(1);
					_ist.setDamageValue(0);
				}
			}
			if (Mth.nextInt(RandomSource.create(), 1, 3) == 1) {
				world.setBlock(BlockPos.containing(x, y, z), RealWaterModBlocks.BULKY_COTTON_2.get().defaultBlockState(), 3);
			}
		} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == RealWaterModBlocks.BULKY_COTTON_2.get()) {
			{
				ItemStack _ist = (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY);
				if (_ist.hurt(1, RandomSource.create(), null)) {
					_ist.shrink(1);
					_ist.setDamageValue(0);
				}
			}
			if (Mth.nextInt(RandomSource.create(), 1, 3) == 1) {
				world.setBlock(BlockPos.containing(x, y, z), RealWaterModBlocks.BULKY_COTTON_1.get().defaultBlockState(), 3);
			}
		} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == RealWaterModBlocks.BULKY_COTTON_1.get()) {
			{
				ItemStack _ist = (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY);
				if (_ist.hurt(1, RandomSource.create(), null)) {
					_ist.shrink(1);
					_ist.setDamageValue(0);
				}
			}
			if (Mth.nextInt(RandomSource.create(), 1, 3) == 1) {
				world.setBlock(BlockPos.containing(x, y, z), RealWaterModBlocks.BULKY_COTTON.get().defaultBlockState(), 3);
			}
		}
	}
}
