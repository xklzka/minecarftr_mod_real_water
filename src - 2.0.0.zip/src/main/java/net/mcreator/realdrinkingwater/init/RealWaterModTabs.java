
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.realdrinkingwater.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.realdrinkingwater.RealWaterMod;

public class RealWaterModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, RealWaterMod.MODID);
	public static final RegistryObject<CreativeModeTab> REAL_WATER = REGISTRY.register("real_water",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.real_water.real_water")).icon(() -> new ItemStack(RealWaterModItems.WATER_BOTTELNONE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(RealWaterModItems.WATER_BOTTELNONE.get());
				tabData.accept(RealWaterModItems.WATER_BOTTLE_DIRT.get());
				tabData.accept(RealWaterModItems.GAUZE.get());
				tabData.accept(RealWaterModItems.LITTLE_STONE.get());
				tabData.accept(RealWaterModItems.QUARTZ_SAND.get());
				tabData.accept(RealWaterModItems.ACTIVATED_CARBON.get());
				tabData.accept(RealWaterModItems.WIRE_DRAWING_APPARATUS.get());
				tabData.accept(RealWaterModBlocks.BULKY_COTTON.get().asItem());
				tabData.accept(RealWaterModBlocks.BULKY_COTTON_1.get().asItem());
				tabData.accept(RealWaterModBlocks.BULKY_COTTON_2.get().asItem());
				tabData.accept(RealWaterModBlocks.BULKY_COTTON_3.get().asItem());
				tabData.accept(RealWaterModItems.LITTLE_BULKY_COTTON.get());
				tabData.accept(RealWaterModItems.LARGE_PARTICLE_FILTER.get());
				tabData.accept(RealWaterModItems.SMALL_PARTICLE_FILTER.get());
				tabData.accept(RealWaterModItems.ACTIVATED_CARBON_PARTICLE_FILTER.get());
				tabData.accept(RealWaterModItems.VERY_SMALL_PARTICLE_FILTER.get());
				tabData.accept(RealWaterModItems.WATER_PURIFIER.get());
				tabData.accept(RealWaterModItems.CLEAN_WATER.get());
				tabData.accept(RealWaterModItems.HOT_WATER.get());
				tabData.accept(RealWaterModItems.COOL_HOT_WATER.get());
			})

					.build());
}
