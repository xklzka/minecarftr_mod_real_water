package net.mcreator.compressedtnt.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;
import net.minecraft.commands.CommandSourceStack;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.arguments.DoubleArgumentType;

public class RealWaterHelpProcedure {
	public static void execute(CommandContext<CommandSourceStack> arguments, Entity entity) {
		if (entity == null)
			return;
		if (DoubleArgumentType.getDouble(arguments, "page") == 1) {
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u00A73----\u771F\u5B9E\u996E\u6C34\u6A21\u7EC4\u6559\u7A0B \u7B2C\u4E00\u9762----"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u7A7A\u6C34\u74F6:\u4F7F\u7528\u4E00\u4E2A\u73BB\u7483\u74F6\u5728\u5DE5\u4F5C\u53F0\u5408\u6210(\u65E0\u5E8F)\u3002"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal(
						"\u6D51\u6D4A\u7684\u6C34\u74F6:\u62FF\u7740\u7A7A\u6C34\u74F6\u5BF9\u6709\u6C34\u7684\u70BC\u836F\u9505\u53F3\u952E\uFF0C\u8FD9\u5C06\u6D88\u8017\u4E00\u683C\u70BC\u836F\u9505\u7684\u6C34\u3002\u4E0D\u56DE\u590D\u6C34\u3002"),
						false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u5F00\u6C34:\u5728\u7194\u7089\u4E2D\u70E7\u6DF7\u6D4A\u7684\u6C34\u74F6\u3002\u56DE\u590D3\u70B9\u6C34\u3002"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u51C9\u5F00\u6C34:\u5F00\u6C34\u6BCF\u523B\u67091/3600\u7684\u51E0\u7387\u53D8\u4E3A\u51C9\u5F00\u6C34\u3002\u56DE\u590D4\u70B9\u6C34\u3002"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u00A73----\u771F\u5B9E\u996E\u6C34\u6A21\u7EC4\u6559\u7A0B \u7B2C\u4E00\u9762 \u00A72\u5230\u6B64\u4E3A\u6B62\u00A73----"), false);
		}
		if (DoubleArgumentType.getDouble(arguments, "page") == 2) {
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u00A73----\u771F\u5B9E\u996E\u6C34\u6A21\u7EC4\u6559\u7A0B \u7B2C\u4E8C\u9762----"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal(
						"\u7EAF\u51C0\u6C34:\u7531\u51C0\u6C34\u5668\u548C\u6D51\u6D4A\u7684\u6C34\u74F6\u5728\u5DE5\u4F5C\u53F0\u5408\u6210(\u65E0\u5E8F)\uFF0C\u5408\u6210\u5C06\u6D88\u80171\u70B9\u51C0\u6C34\u5668\u7684\u8010\u4E45\u503C\u3002\u56DE\u590D6\u70B9\u6C34\u3002"),
						false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal(
						"\u51C0\u6C34\u5668:\u7531\u5927\u9897\u7C92\u6EE4\u7F51\u3001\u5C0F\u9897\u7C92\u6EE4\u7F51\u3001\u6D3B\u6027\u70AD\u6EE4\u7F51\u3001\u6781\u5C0F\u9897\u7C92\u6EE4\u7F51\u5728\u5DE5\u4F5C\u53F0\u5408\u6210(\u65E0\u5E8F)\u3002\u6709500\u8010\u4E45\u5EA6\u3002"),
						false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u7EB1\u5E03:\u9700\u8981\u7F8A\u6BDB\u3001\u7EBF\u5408\u62102\u4E2A\uFF0C\u5177\u4F53\u5408\u6210\u65B9\u5F0F\u89C1\u914D\u65B9\u4E66\u3002"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u5927\u9897\u7C92\u6EE4\u7F51:\u9700\u8981\u7EB1\u5E03\u3001\u77F3\u5B50\uFF0C\u5177\u4F53\u5408\u6210\u65B9\u5F0F\u89C1\u914D\u65B9\u4E66\u3002"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u77F3\u5B50:\u7531\u539F\u77F3\u3001\u71E7\u77F3\u5404\u4E00\u4E2A\u5728\u5DE5\u4F5C\u53F0\u5408\u62104\u4E2A(\u65E0\u5E8F)\u3002"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u5C0F\u9897\u7C92\u6EE4\u7F51:\u9700\u8981\u7EB1\u5E03\u3001\u77F3\u82F1\u7802\u5408\u6210\uFF0C\u5177\u4F53\u5408\u6210\u65B9\u5F0F\u89C1\u914D\u65B9\u4E66\u3002"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u77F3\u82F1\u7802:\u7531\u77F3\u82F13\u4E2A\u3001\u71E7\u77F31\u4E2A\u5728\u5DE5\u4F5C\u53F0\u5408\u62106\u4E2A(\u65E0\u5E8F)\u3002"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u00A73----\u771F\u5B9E\u996E\u6C34\u6A21\u7EC4\u6559\u7A0B \u7B2C\u4E8C\u9762 \u00A72\u5230\u6B64\u4E3A\u6B62\u00A73 ----"), false);
		}
		if (DoubleArgumentType.getDouble(arguments, "page") == 3) {
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u00A73----\u771F\u5B9E\u996E\u6C34\u6A21\u7EC4\u6559\u7A0B \u7B2C\u4E09\u9762----"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u6D3B\u6027\u70AD\u6EE4\u7F51:\u9700\u8981\u7EB1\u5E03\u3001\u6D3B\u6027\u70AD\uFF0C\u5177\u4F53\u5408\u6210\u65B9\u5F0F\u89C1\u914D\u65B9\u4E66\u3002"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u6D3B\u6027\u70AD:\u7531\u7164\u70AD\u6216\u6728\u70AD\u5728\u7194\u7089\u4E2D\u70E7\u70BC\u5F97\u5230\u3002"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u6781\u5C0F\u9897\u7C92\u6EE4\u7F51:\u9700\u8981\u7EB1\u5E03\u3001\u5C0F\u5757\u84EC\u677E\u68C9\u5408\u6210\uFF0C\u5177\u4F53\u5408\u6210\u65B9\u5F0F\u89C1\u914D\u65B9\u4E66\u3002"),
						false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u5C0F\u5757\u84EC\u677E\u68C9:\u75311\u4E2A\u84EC\u677E\u68C9\u5728\u5DE5\u4F5C\u53F0\u5206\u89E3\u5F97\u52303\u4E2A(\u65E0\u5E8F)\u3002"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal(
						"\u84EC\u677E\u68C9:\u4F7F\u7528\u62C9\u4E1D\u5668\u5BF9\u7F8A\u6BDB\u4F7F\u7528\u67091/3\u7684\u6982\u7387\u4F7F\u5176\u53D8\u4E3A\u8F83\u4E0D\u84EC\u677E\u68C9\uFF0C\u518D\u4F7F\u7528\u62C9\u4E1D\u5668\u6709\u540C\u6837\u7684\u6982\u7387\u4F7F\u5176\u53D8\u4E3A\u534A\u84EC\u677E\u68C9\uFF0C\u4EE5\u6B64\u7C7B\u63A8\uFF0C\u7EE7\u7EED\u53D8\u6210\u8F83\u84EC\u677E\u68C9\u548C\u84EC\u677E\u68C9\u3002\u6BCF\u6B21\u62C9\u4E1D\u6D88\u80171\u70B9\u8010\u4E45\u3002"),
						false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u62C9\u4E1D\u5668:\u7531\u6728\u68CD\u5408\u6210\uFF0C\u670960\u8010\u4E45\u3002"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u00A73----\u771F\u5B9E\u996E\u6C34\u6A21\u7EC4\u6559\u7A0B \u7B2C\u4E09\u9762 \u00A72\u5230\u6B64\u4E3A\u6B62\u00A73 ----"), false);
		}
		if (DoubleArgumentType.getDouble(arguments, "page") == 4) {
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u00A73----\u771F\u5B9E\u996E\u6C34\u6A21\u7EC4\u6559\u7A0B \u7B2C\u56DB\u9762----"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal(
						"\u996E\u6C34\u673A\u5236:\u6BCF\u4E2A\u73A9\u5BB6\u6700\u9AD8\u670920\u70B9\u6C34\uFF0C\u590D\u6D3B\u91CD\u7F6E\u4E8E20\u3002\u6BCF\u523B\u67091/1200*X\u7684\u51E0\u7387\u6D88\u80171\u70B9\u6C34\uFF0CX\u7684\u8BA1\u7B97\u89C1\u4E0B(\u4F18\u5148\u5EA6\u4E3A\u4E0A\u4E0B\u987A\u5E8F)\u3002"),
						false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("1.X=1"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("2.\u82E5\u73A9\u5BB6\u5728\u6C34\u3001\u96E8\u6216\u6C14\u6CE1\u67F1\u5185\uFF0CX=0"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("3.\u82E5\u73A9\u5BB6\u7981\u6B62\uFF0CX=0"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("4.\u82E5\u73A9\u5BB6\u5728\u4E0B\u754C\uFF0CX=X * 2 + 1"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("5.\u82E5\u73A9\u5BB6\u5728\u75BE\u8DD1\uFF0CX=X * 1.25"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("6.\u82E5\u73A9\u5BB6\u5728\u71C3\u70E7\uFF0CX=X * 1.75"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u00A73----\u771F\u5B9E\u996E\u6C34\u6A21\u7EC4\u6559\u7A0B \u7B2C\u56DB\u9762 \u00A72\u5230\u6B64\u4E3A\u6B62\u00A73 ----"), false);
		}
		if (DoubleArgumentType.getDouble(arguments, "page") == 5) {
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u00A73----\u771F\u5B9E\u996E\u6C34\u6A21\u7EC4\u6559\u7A0B \u7B2C\u4E94\u9762----"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal(
						"/setwater:\u8BED\u6CD5:/setwater \u73A9\u5BB6\u540D \u6C34\u7684\u6570\u91CF | \u6548\u679C:\u8BBE\u7F6E\u73A9\u5BB6\u7684\u6C34\u91CF | \u6CE8\u610F:\u6C34\u7684\u6570\u91CF\u8981\u57280\u523020\u4E4B\u95F4\uFF0C\u9700\u8981\u6743\u9650\u7B49\u7EA72"),
						false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("/lookwater:\u8BED\u6CD5:/lookwater | \u6548\u679C:\u67E5\u770B\u81EA\u5DF1\u7684\u6C34\u91CF | \u6CE8\u610F:\u9700\u8981\u6743\u9650\u7B49\u7EA71"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal(
						"/realwaterhelp:\u8BED\u6CD5:/realwaterhelp \u9875\u7801 | \u6548\u679C:\u83B7\u53D6\u6B64\u6A21\u7EC4\u7684\u5E2E\u52A9 | \u6CE8\u610F:\u9875\u7801\u662F\u53EF\u9009\u7684\uFF0C\u9875\u7801\u8981\u57281-5\u4E4B\u95F4\uFF0C\u9700\u8981\u6743\u9650\u7B49\u7EA71"),
						false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u6E38\u620F\u89C4\u5219showWaterTime:\u51B3\u5B9A\u6BCF\u9694\u591A\u5C11\u523B\u663E\u793A\u73A9\u5BB6\u7684\u6C34\u91CF\uFF0C\u9ED8\u8BA4600\u523B\u3002 "), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u6E38\u620F\u89C4\u5219useWaterShow:\u51B3\u5B9A\u73A9\u5BB6\u6D88\u8017\u6C34\u662F\u662F\u5426\u663E\u793A\uFF0C\u9ED8\u8BA4true\u3002 "), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u6C34\u8FC7\u4F4E\u4F24\u5BB3:\u5F53\u6C34\u91CF\u8FC7\u4F4E\u662F\uFF0C\u4F1A\u4EA7\u751F2\u70B9\u751F\u547D\u503C/20\u523B\u7684\u4F24\u5BB3\u3002"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u00A73----\u771F\u5B9E\u996E\u6C34\u6A21\u7EC4\u6559\u7A0B \u7B2C\u4E94\u9762 \u00A72\u5230\u6B64\u4E3A\u6B62\u00A73 ----"), false);
		}
	}
}
