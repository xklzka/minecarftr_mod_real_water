package net.mcreator.compressedtnt.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.TickEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

import net.mcreator.compressedtnt.network.RealWaterModVariables;
import net.mcreator.compressedtnt.init.RealWaterModGameRules;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class ShowWaterLeftProcedure {
	@SubscribeEvent
	public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			execute(event, event.player.level(), event.player);
		}
	}

	public static void execute(LevelAccessor world, Entity entity) {
		execute(null, world, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		RealWaterModVariables.MapVariables.get(world).time_count_1 = RealWaterModVariables.MapVariables.get(world).time_count_1 + 1;
		RealWaterModVariables.MapVariables.get(world).syncData(world);
		if (RealWaterModVariables.MapVariables.get(world).time_count_1 >= (world.getLevelData().getGameRules().getInt(RealWaterModGameRules.SHOW_WATER_TIME))) {
			RealWaterModVariables.MapVariables.get(world).time_count_1 = 0;
			RealWaterModVariables.MapVariables.get(world).syncData(world);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(
						Component.literal(("\u4F60\u8FD8\u6709" + (entity.getCapability(RealWaterModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new RealWaterModVariables.PlayerVariables())).water + "\u7684\u6C34(\u6EE1\u4E3A20)")), false);
		}
	}
}
