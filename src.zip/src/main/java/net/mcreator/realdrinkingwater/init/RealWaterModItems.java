
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.realdrinkingwater.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.realdrinkingwater.item.WireDrawingApparatusItem;
import net.mcreator.realdrinkingwater.item.WaterPurifierItem;
import net.mcreator.realdrinkingwater.item.WaterBottleDirtItem;
import net.mcreator.realdrinkingwater.item.WaterBottelnoneItem;
import net.mcreator.realdrinkingwater.item.VerySmallParticleFilterItem;
import net.mcreator.realdrinkingwater.item.SmallParticleFilterItem;
import net.mcreator.realdrinkingwater.item.QuartzSandItem;
import net.mcreator.realdrinkingwater.item.LittleStoneItem;
import net.mcreator.realdrinkingwater.item.LittleBulkyCottonItem;
import net.mcreator.realdrinkingwater.item.LargeParticleFilterItem;
import net.mcreator.realdrinkingwater.item.HotWaterItem;
import net.mcreator.realdrinkingwater.item.GauzeItem;
import net.mcreator.realdrinkingwater.item.CoolHotWaterItem;
import net.mcreator.realdrinkingwater.item.CleanWaterItem;
import net.mcreator.realdrinkingwater.item.ActivatedCarbonParticleFilterItem;
import net.mcreator.realdrinkingwater.item.ActivatedCarbonItem;
import net.mcreator.realdrinkingwater.RealWaterMod;

public class RealWaterModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, RealWaterMod.MODID);
	public static final RegistryObject<Item> WATER_BOTTELNONE = REGISTRY.register("water_bottelnone", () -> new WaterBottelnoneItem());
	public static final RegistryObject<Item> WATER_BOTTLE_DIRT = REGISTRY.register("water_bottle_dirt", () -> new WaterBottleDirtItem());
	public static final RegistryObject<Item> GAUZE = REGISTRY.register("gauze", () -> new GauzeItem());
	public static final RegistryObject<Item> LITTLE_STONE = REGISTRY.register("little_stone", () -> new LittleStoneItem());
	public static final RegistryObject<Item> QUARTZ_SAND = REGISTRY.register("quartz_sand", () -> new QuartzSandItem());
	public static final RegistryObject<Item> ACTIVATED_CARBON = REGISTRY.register("activated_carbon", () -> new ActivatedCarbonItem());
	public static final RegistryObject<Item> WIRE_DRAWING_APPARATUS = REGISTRY.register("wire_drawing_apparatus", () -> new WireDrawingApparatusItem());
	public static final RegistryObject<Item> BULKY_COTTON = block(RealWaterModBlocks.BULKY_COTTON);
	public static final RegistryObject<Item> BULKY_COTTON_1 = block(RealWaterModBlocks.BULKY_COTTON_1);
	public static final RegistryObject<Item> BULKY_COTTON_2 = block(RealWaterModBlocks.BULKY_COTTON_2);
	public static final RegistryObject<Item> BULKY_COTTON_3 = block(RealWaterModBlocks.BULKY_COTTON_3);
	public static final RegistryObject<Item> LITTLE_BULKY_COTTON = REGISTRY.register("little_bulky_cotton", () -> new LittleBulkyCottonItem());
	public static final RegistryObject<Item> LARGE_PARTICLE_FILTER = REGISTRY.register("large_particle_filter", () -> new LargeParticleFilterItem());
	public static final RegistryObject<Item> SMALL_PARTICLE_FILTER = REGISTRY.register("small_particle_filter", () -> new SmallParticleFilterItem());
	public static final RegistryObject<Item> ACTIVATED_CARBON_PARTICLE_FILTER = REGISTRY.register("activated_carbon_particle_filter", () -> new ActivatedCarbonParticleFilterItem());
	public static final RegistryObject<Item> VERY_SMALL_PARTICLE_FILTER = REGISTRY.register("very_small_particle_filter", () -> new VerySmallParticleFilterItem());
	public static final RegistryObject<Item> WATER_PURIFIER = REGISTRY.register("water_purifier", () -> new WaterPurifierItem());
	public static final RegistryObject<Item> CLEAN_WATER = REGISTRY.register("clean_water", () -> new CleanWaterItem());
	public static final RegistryObject<Item> HOT_WATER = REGISTRY.register("hot_water", () -> new HotWaterItem());
	public static final RegistryObject<Item> COOL_HOT_WATER = REGISTRY.register("cool_hot_water", () -> new CoolHotWaterItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
