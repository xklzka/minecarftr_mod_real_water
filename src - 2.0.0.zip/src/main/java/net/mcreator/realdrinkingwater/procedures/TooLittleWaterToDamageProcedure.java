package net.mcreator.realdrinkingwater.procedures;

import net.minecraftforge.eventbus.api.Event;

import net.mcreator.realdrinkingwater.network.RealWaterModVariables;

@Mod.EventBusSubscriber
public class TooLittleWaterToDamageProcedure {
	@SubscribeEvent
	public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			execute(event, event.player.level(), event.player);
		}
	}

	public static void execute(LevelAccessor world, Entity entity) {
		execute(null, world, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		{
			double _setval = (entity.getCapability(RealWaterModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new RealWaterModVariables.PlayerVariables())).time_count_2 + 1;
			entity.getCapability(RealWaterModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.time_count_2 = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
		if ((entity.getCapability(RealWaterModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new RealWaterModVariables.PlayerVariables())).time_count_2 >= 20) {
			{
				double _setval = 0;
				entity.getCapability(RealWaterModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.time_count_2 = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			if ((entity.getCapability(RealWaterModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new RealWaterModVariables.PlayerVariables())).water == 0) {
				entity.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation("real_water:too_little_water")))), 2);
				if (!(entity instanceof ServerPlayer _plr2 && _plr2.level() instanceof ServerLevel && _plr2.getAdvancements().getOrStartProgress(_plr2.server.getAdvancements().getAdvancement(new ResourceLocation("real_water:thirst"))).isDone())) {
					if (entity instanceof ServerPlayer _player) {
						Advancement _adv = _player.server.getAdvancements().getAdvancement(new ResourceLocation("real_water:thirst"));
						AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
						if (!_ap.isDone()) {
							for (String criteria : _ap.getRemainingCriteria())
								_player.getAdvancements().award(_adv, criteria);
						}
					}
				}
			}
		}
	}
}
