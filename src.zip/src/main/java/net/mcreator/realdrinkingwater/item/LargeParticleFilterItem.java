
package net.mcreator.realdrinkingwater.item;

public class LargeParticleFilterItem extends Item {
	public LargeParticleFilterItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
