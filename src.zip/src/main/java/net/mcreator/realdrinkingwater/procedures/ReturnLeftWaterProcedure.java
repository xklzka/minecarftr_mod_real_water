package net.mcreator.realdrinkingwater.procedures;

import net.mcreator.realdrinkingwater.network.RealWaterModVariables;

public class ReturnLeftWaterProcedure {
	public static String execute(Entity entity) {
		if (entity == null)
			return "";
		return "" + (entity.getCapability(RealWaterModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new RealWaterModVariables.PlayerVariables())).water;
	}
}
