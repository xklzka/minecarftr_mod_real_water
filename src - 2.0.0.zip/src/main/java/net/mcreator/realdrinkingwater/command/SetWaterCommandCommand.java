
package net.mcreator.realdrinkingwater.command;

import net.mcreator.realdrinkingwater.procedures.SetWaterProcedure;

@Mod.EventBusSubscriber
public class SetWaterCommandCommand {
	@SubscribeEvent
	public static void registerCommand(RegisterCommandsEvent event) {
		event.getDispatcher().register(
				Commands.literal("setwater").requires(s -> s.hasPermission(2)).then(Commands.argument("set_water_players", EntityArgument.players()).then(Commands.argument("how_much_water", DoubleArgumentType.doubleArg(0, 20)).executes(arguments -> {
					Level world = arguments.getSource().getUnsidedLevel();
					double x = arguments.getSource().getPosition().x();
					double y = arguments.getSource().getPosition().y();
					double z = arguments.getSource().getPosition().z();
					Entity entity = arguments.getSource().getEntity();
					if (entity == null && world instanceof ServerLevel _servLevel)
						entity = FakePlayerFactory.getMinecraft(_servLevel);
					Direction direction = Direction.DOWN;
					if (entity != null)
						direction = entity.getDirection();

					SetWaterProcedure.execute(arguments);
					return 0;
				}))));
	}
}
