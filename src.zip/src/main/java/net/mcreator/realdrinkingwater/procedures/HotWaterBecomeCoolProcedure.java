package net.mcreator.realdrinkingwater.procedures;

import net.minecraftforge.eventbus.api.Event;

import net.mcreator.realdrinkingwater.init.RealWaterModItems;

@Mod.EventBusSubscriber
public class HotWaterBecomeCoolProcedure {
	@SubscribeEvent
	public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			execute(event, event.player);
		}
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		double WaterBecomeCollTimes = 0;
		if (Mth.nextInt(RandomSource.create(), 1, 3600) == 1) {
			WaterBecomeCollTimes = 0;
			while (entity instanceof Player _playerHasItem ? _playerHasItem.getInventory().contains(new ItemStack(RealWaterModItems.HOT_WATER.get())) : false) {
				WaterBecomeCollTimes = WaterBecomeCollTimes + 1;
				if (entity instanceof Player _player) {
					ItemStack _stktoremove = new ItemStack(RealWaterModItems.HOT_WATER.get());
					_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
				}
				if (entity instanceof Player _player) {
					ItemStack _setstack = new ItemStack(RealWaterModItems.COOL_HOT_WATER.get()).copy();
					_setstack.setCount(1);
					ItemHandlerHelper.giveItemToPlayer(_player, _setstack);
				}
				if (WaterBecomeCollTimes >= 2304) {
					break;
				}
			}
		}
	}
}
