
package net.mcreator.realdrinkingwater.item;

import net.mcreator.realdrinkingwater.procedures.WaterBottelnoneDangYouJiFangKuaiShiFangKuaiDeWeiZhiProcedure;

public class WaterBottelnoneItem extends Item {
	public WaterBottelnoneItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}

	@Override
	public InteractionResult useOn(UseOnContext context) {
		super.useOn(context);
		WaterBottelnoneDangYouJiFangKuaiShiFangKuaiDeWeiZhiProcedure.execute(context.getLevel(), context.getClickedPos().getX(), context.getClickedPos().getY(), context.getClickedPos().getZ(),
				context.getLevel().getBlockState(context.getClickedPos()), context.getPlayer());
		return InteractionResult.SUCCESS;
	}
}
