
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.realdrinkingwater.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.realdrinkingwater.block.BulkyCottonBlock;
import net.mcreator.realdrinkingwater.block.BulkyCotton3Block;
import net.mcreator.realdrinkingwater.block.BulkyCotton2Block;
import net.mcreator.realdrinkingwater.block.BulkyCotton1Block;
import net.mcreator.realdrinkingwater.RealWaterMod;

public class RealWaterModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, RealWaterMod.MODID);
	public static final RegistryObject<Block> BULKY_COTTON = REGISTRY.register("bulky_cotton", () -> new BulkyCottonBlock());
	public static final RegistryObject<Block> BULKY_COTTON_1 = REGISTRY.register("bulky_cotton_1", () -> new BulkyCotton1Block());
	public static final RegistryObject<Block> BULKY_COTTON_2 = REGISTRY.register("bulky_cotton_2", () -> new BulkyCotton2Block());
	public static final RegistryObject<Block> BULKY_COTTON_3 = REGISTRY.register("bulky_cotton_3", () -> new BulkyCotton3Block());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
