
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.compressedtnt.init;

import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.GameRules;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class RealWaterModGameRules {
	public static final GameRules.Key<GameRules.IntegerValue> SHOW_WATER_TIME = GameRules.register("showWaterTime", GameRules.Category.PLAYER, GameRules.IntegerValue.create(600));
	public static final GameRules.Key<GameRules.BooleanValue> USE_WATER_SHOW = GameRules.register("useWaterShow", GameRules.Category.PLAYER, GameRules.BooleanValue.create(true));
}
