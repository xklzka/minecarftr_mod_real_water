
package net.mcreator.realdrinkingwater.client.screens;

import net.mcreator.realdrinkingwater.procedures.ReturnLeftWaterProcedure;

@Mod.EventBusSubscriber({Dist.CLIENT})
public class ShowWaterOverlay {
	@SubscribeEvent(priority = EventPriority.NORMAL)
	public static void eventHandler(RenderGuiEvent.Pre event) {
		int w = event.getWindow().getGuiScaledWidth();
		int h = event.getWindow().getGuiScaledHeight();
		Level world = null;
		double x = 0;
		double y = 0;
		double z = 0;
		Player entity = Minecraft.getInstance().player;
		if (entity != null) {
			world = entity.level();
			x = entity.getX();
			y = entity.getY();
			z = entity.getZ();
		}
		if (true) {
			event.getGuiGraphics().drawString(Minecraft.getInstance().font,

					ReturnLeftWaterProcedure.execute(entity), w / 2 + 173, h / 2 + 107, -1, false);
			event.getGuiGraphics().drawString(Minecraft.getInstance().font, Component.translatable("gui.real_water.show_water.label_huan_sheng_yu_dian_shui"), w / 2 + 115, h / 2 + 107, -1, false);
		}
	}
}
