
package net.mcreator.realdrinkingwater.item;

import net.mcreator.realdrinkingwater.procedures.WireDrawingApparatusDangYouJiFangKuaiShiFangKuaiDeWeiZhiProcedure;

public class WireDrawingApparatusItem extends Item {
	public WireDrawingApparatusItem() {
		super(new Item.Properties().durability(60).rarity(Rarity.COMMON));
	}

	@Override
	public InteractionResult useOn(UseOnContext context) {
		super.useOn(context);
		WireDrawingApparatusDangYouJiFangKuaiShiFangKuaiDeWeiZhiProcedure.execute(context.getLevel(), context.getClickedPos().getX(), context.getClickedPos().getY(), context.getClickedPos().getZ(), context.getPlayer());
		return InteractionResult.SUCCESS;
	}
}
