
package net.mcreator.realdrinkingwater.item;

public class ActivatedCarbonItem extends Item {
	public ActivatedCarbonItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
