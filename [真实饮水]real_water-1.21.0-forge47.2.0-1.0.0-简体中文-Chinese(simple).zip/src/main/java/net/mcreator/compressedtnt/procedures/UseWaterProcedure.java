package net.mcreator.compressedtnt.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.TickEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.network.chat.Component;

import net.mcreator.compressedtnt.network.RealWaterModVariables;
import net.mcreator.compressedtnt.init.RealWaterModGameRules;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class UseWaterProcedure {
	@SubscribeEvent
	public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			execute(event, event.player.level(), event.player);
		}
	}

	public static void execute(LevelAccessor world, Entity entity) {
		execute(null, world, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		double use_water_times = 0;
		use_water_times = 1;
		if (entity.isInWaterRainOrBubble()) {
			use_water_times = 0;
		}
		if (entity.getDeltaMovement().x() + entity.getDeltaMovement().y() + entity.getDeltaMovement().z() == 0) {
			use_water_times = 0;
		}
		if (Mth.nextInt(RandomSource.create(), 1, 600) == 1) {
			if ((entity.level().dimension()) == Level.NETHER) {
				use_water_times = use_water_times * 2 + 1;
			}
		}
		if (entity.isSprinting()) {
			use_water_times = use_water_times * 1.25;
		}
		if (entity.isOnFire()) {
			use_water_times = use_water_times * 1.75;
		}
		if (Mth.nextInt(RandomSource.create(), 1, (int) (1200 / use_water_times)) == 1 && use_water_times != 0) {
			{
				double _setval = (entity.getCapability(RealWaterModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new RealWaterModVariables.PlayerVariables())).water - 1;
				entity.getCapability(RealWaterModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.water = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			if ((entity.getCapability(RealWaterModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new RealWaterModVariables.PlayerVariables())).water < 0) {
				{
					double _setval = 0;
					entity.getCapability(RealWaterModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.water = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			}
			if (world.getLevelData().getGameRules().getBoolean(RealWaterModGameRules.USE_WATER_SHOW)) {
				if (entity instanceof Player _player && !_player.level().isClientSide())
					_player.displayClientMessage(Component.literal(("\u4F60\u4F7F\u7528\u4E861\u7684\u6C34\uFF0C\u4F60\u8FD8\u5269"
							+ (entity.getCapability(RealWaterModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new RealWaterModVariables.PlayerVariables())).water + "\u7684\u6C34")), false);
			}
		}
	}
}
