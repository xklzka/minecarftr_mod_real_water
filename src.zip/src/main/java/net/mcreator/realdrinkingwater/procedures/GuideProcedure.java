package net.mcreator.realdrinkingwater.procedures;

import net.minecraftforge.eventbus.api.Event;

import net.mcreator.realdrinkingwater.RealWaterMod;

@Mod.EventBusSubscriber
public class GuideProcedure {
	@SubscribeEvent
	public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
		execute(event, event.getEntity().level(), event.getEntity());
	}

	public static void execute(LevelAccessor world, Entity entity) {
		execute(null, world, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		RealWaterMod.queueServerWork(20, () -> {
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("Real Drinking Water: You can get guide at https://realdrinkingwatermodminecraft.fandom.com/wiki/RealDrinkingWaterMod(Minecraft)_Wiki"), false);
		});
	}
}
