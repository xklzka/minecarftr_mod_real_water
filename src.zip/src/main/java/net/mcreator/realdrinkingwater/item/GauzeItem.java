
package net.mcreator.realdrinkingwater.item;

public class GauzeItem extends Item {
	public GauzeItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
