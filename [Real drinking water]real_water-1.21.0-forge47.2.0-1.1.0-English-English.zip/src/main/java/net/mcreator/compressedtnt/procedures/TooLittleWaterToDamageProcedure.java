package net.mcreator.compressedtnt.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.TickEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.Advancement;

import net.mcreator.compressedtnt.network.RealWaterModVariables;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class TooLittleWaterToDamageProcedure {
	@SubscribeEvent
	public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			execute(event, event.player.level(), event.player);
		}
	}

	public static void execute(LevelAccessor world, Entity entity) {
		execute(null, world, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		{
			double _setval = (entity.getCapability(RealWaterModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new RealWaterModVariables.PlayerVariables())).time_count_2 + 1;
			entity.getCapability(RealWaterModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.time_count_2 = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
		if ((entity.getCapability(RealWaterModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new RealWaterModVariables.PlayerVariables())).time_count_2 >= 20) {
			{
				double _setval = 0;
				entity.getCapability(RealWaterModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.time_count_2 = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			if ((entity.getCapability(RealWaterModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new RealWaterModVariables.PlayerVariables())).water == 0) {
				entity.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation("real_water:too_little_water")))), 2);
				if (!(entity instanceof ServerPlayer _plr2 && _plr2.level() instanceof ServerLevel && _plr2.getAdvancements().getOrStartProgress(_plr2.server.getAdvancements().getAdvancement(new ResourceLocation("real_water:thirst"))).isDone())) {
					if (entity instanceof ServerPlayer _player) {
						Advancement _adv = _player.server.getAdvancements().getAdvancement(new ResourceLocation("real_water:thirst"));
						AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
						if (!_ap.isDone()) {
							for (String criteria : _ap.getRemainingCriteria())
								_player.getAdvancements().award(_adv, criteria);
						}
					}
				}
			}
		}
	}
}
