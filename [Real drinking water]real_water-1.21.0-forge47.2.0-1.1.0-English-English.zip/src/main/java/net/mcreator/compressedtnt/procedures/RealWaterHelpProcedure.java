package net.mcreator.compressedtnt.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;
import net.minecraft.commands.CommandSourceStack;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.arguments.DoubleArgumentType;

public class RealWaterHelpProcedure {
	public static void execute(CommandContext<CommandSourceStack> arguments, Entity entity) {
		if (entity == null)
			return;
		if (DoubleArgumentType.getDouble(arguments, "page") == 1) {
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u00A73---- Real Drinking Water Mod Tutorial Side 1----"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("Empty Water Bottle: Use a glass bottle to craft on the crafting table (disordered)."), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("Cloudy Water Bottle: Right-click on the cauldron with water while holding an empty water bottle, which will consume one block of cauldron water. Does not reply to water."), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("Boiling water: Burn a cloudy water bottle in a furnace. Restores 3 water."), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("Cool Water: Boiled water has a 1/3600 chance to turn into cool water every moment. Restores 4 water."), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u00A73---- Real Drinking Water Mod Tutorial Side 1 \u00A72end\u00A73----"), false);
		}
		if (DoubleArgumentType.getDouble(arguments, "page") == 2) {
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u00A73---- Real Drinking Water Mod Tutorial Side 2----"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("Purified Water: Crafted from a Water Purifier and a Cloudy Water Bottle on a Crafting Table (Discord), the synthesis consumes 1 Water Purifier's durability. Restores 6 water."), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(
						Component.literal(
								"Water purifier: It is synthesized by a large particle filter, a small particle filter, an activated carbon filter, and a very small particle filter screen in the workbench (disordered). There is 500 durability."),
						false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("Gauze: 2 wool and thread are needed to synthesize, and the specific synthesis method is shown in the recipe book."), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("Large particle filter: gauze and stones are required, and the specific synthesis method is shown in the recipe book."), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("Stones: Crafting 4 pieces of Primogem and 1 Flint on the Workbench (Discord)."), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("Small particle filter: gauze and quartz sand are required to synthesize, and the specific synthesis method is shown in the recipe book."), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("Quartz Sand: Crafts 6 pieces of quartz and 1 flint on the workbench (disordered)."), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u00A73---- Real Drinking Water Mod Tutorial Side 2 \u00A72end\u00A73----"), false);
		}
		if (DoubleArgumentType.getDouble(arguments, "page") == 3) {
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u00A73---- Real Drinking Water Mod Tutorial Side 3----"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("Activated carbon filter: gauze and activated carbon are required, and the specific synthesis method is shown in the recipe book."), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("Activated charcoal: It is obtained by smelting coal or charcoal in a furnace."), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("Small pieces of fluffy cotton: 3 pieces of fluffy cotton are broken down on the workbench (disordered)."), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal(
						"Fluffy cotton: Using a wire drawer to use wool has a 1/3 probability of making it less fluffy cotton, and then using a wire drawer has the same probability of making it become semi-fluffy cotton, and so on, continuing to become fluffier cotton and fluffy cotton. Each draw costs 1 durability point."),
						false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("Wire Drawer: Crafted from wooden sticks, it has 60 durability."), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u00A73---- Real Drinking Water Mod Tutorial Side 3 \u00A72end\u00A73----"), false);
		}
		if (DoubleArgumentType.getDouble(arguments, "page") == 4) {
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u00A73---- Real Drinking Water Mod Tutorial Side 4----"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(
						Component.literal("Drinking mechanics: Each player has a maximum of 20 water, and the respawn reset is 20. There is a 1/1200*X chance to cost 1 water per tick, and the calculation of X is shown below (priority is in order)."),
						false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("1.X=1"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("2. If the player is in water, rain, or bubble columns, X=0"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("3. If the player bans, X=0"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("4. If the player is in the Nether, X=X * 2 + 1"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("5. If the player is sprinting, X=X * 1.25"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("6. If the player is burning, X=X * 1.75"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u00A73---- Real Drinking Water Mod Tutorial Side 24\u00A72end\u00A73----"), false);
		}
		if (DoubleArgumentType.getDouble(arguments, "page") == 5) {
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u00A73---- Real Drinking Water Mod Tutorial Side 5----"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("/setwater: syntax: /setwater playername Number of water | Effect: Sets the player's water volume | Note: The amount of water must be between 0 and 20 and requires permission level 2"),
						false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("/lookwater: syntax: /lookwater | Effect: Check your own water volume | Note: Permission Level 1 is required"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(
						Component.literal("/realwaterhelp: syntax: /realwaterhelp page number | Effects: Get help with this mod | Note: Page numbers are optional, page numbers should be between 1-5, and permission level 1 is required"), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("Game rules showWaterTime: Determines how many ticks the player's water volume is displayed, the default is 600 ticks. "), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("Game rules useWaterShow: Determines whether the player's water consumption is displayed or not, the default is true. "), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("Low Water Damage: When the water is too low, it will deal 2 HP/20 ticks of damage."), false);
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u00A73---- Real Drinking Water Mod Tutorial Side 5 \u00A72end\u00A73----"), false);
		}
	}
}
